"""

   This class will be used to perform unit testing of some functions.

"""

import unittest
import io
import sys
from Gamerooms import GameRooms


class TestGameRoom(unittest.TestCase):
    def test_outdooor(self):
        obs_msg = io.StringIO()
        sys.stdout = obs_msg
        GameRooms.outdoor(self)
        sys.stdout = sys.__stdout__
        expected_msg = ('Using the key, you unlock the door and leave the abandoned house!! \n'
                        'Hopefully your friends will believe the adventure you have had :)\n'
                        'CONGRATULATIONS, YOU COMPLETED THE GAME.\n')
        self.assertEqual(expected_msg, obs_msg.getvalue(), 'The contents are not the same')

    def test_hallway(self):
        obs_msg = io.StringIO()
        sys.stdout = obs_msg
        GameRooms.hallway(self)
        sys.stdout = sys.__stdout__
        expected_msg = ('The rooms are: kitchen, living room and the bedroom with the figure. Where would you like to '
                        'go? \n'
                        '[Enter "kitchen" or "livingroom or "bedroom"]\n'
                        '>>> '
                        'Invalid entry\n')
        self.assertEqual(expected_msg, obs_msg.getvalue(), 'The contents are not the same')




if __name__ == '__main__':
    unittest.main()
