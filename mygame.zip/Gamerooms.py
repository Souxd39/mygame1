"""

This class contains all the rooms of the game as a function which includes the events that happens in those rooms.

"""
from Navigate import Room
import tkinter as tk

import time


class GameRooms:
    pocket = ['knife']  # This is a list which will contain the items the user carries.

    def __init__(self, description):
        #self.current_room = None
        self.description = description
        self.exits = {}



    def bedroom(self):
        """

            This function represents the first room of the game.

        """
        
        self.room1 = Room("You are in the room. This room is empty however you see a basement. would you enter it? ["
                          "Enter: 'go basement']")
        self.house = Room("You are now inside the house. You see a room. Would you like to go inside? [Enter: 'go "
                          "room']")
        self.basement = Room("You are in the basement. You see a strange figure approach you. Do you wish to "
                             "interact? [Enter: 'go ahead']")
        self.office = Room("The figure talks. \n Figure: I see that you are here for your football...but inorder to "
                           "get it you will have to pass through some tests. Are you ready? [Enter 'go ahead']")
        self.convo = Room("You should first answer 3 of these questions correctly. [Enter 'ok' to proceed] ")

        

        self.room1.set_exit("inside", self.house)
        self.room1.set_exit("basement", self.basement)
        self.house.set_exit("room", self.room1)
        self.basement.set_exit("ahead", self.office)
        self.office.set_exit("ahead", self.convo)

        self.current_room = self.room1

    

    def basement(self):
        """

            This function performs the activities that happen in the second room of the game. Here there is a true or falls
            in-game feature.

        """

        true = ["T", "t", "True"]
        false = ["F", "f", "False"]  # Multiple entries so that the user may input any entry of their liking and the
        # code will execute.
        correct = 0  # Storing the correct answers

        name = input("But before we begin...What's your name? ")
        print(
            "\n OK, " + name + ", let's get started. Remember, the following answers are only True or False. [Enter t or f]")

        print("\nLondon is in England.")
        choice = input(">>> ")
        if choice in true:
            correct += 1
        else:
            correct += 0

        print("\nIndia is a continent.")
        choice = input(">>> ")
        if choice in false:
            correct += 1
        else:
            correct += 0

        print("\nWinters are warm.")
        choice = input(">>> ")
        if choice in false:
            correct += 1
        else:
            correct += 0

        print("\nWell," + name + ". You got", correct, "out of 3 correct.")
        time.sleep(1)

        if correct == 3:
            print('The figure: "Good job. I did not expect you to get all of that right. '
                  'Well, your football is upstairs. you may go and collect it."')
            time.sleep(1)
            return GameRooms.upstairs(self)  # The user proceeds to the next room

        else:
            print('Figure: "Uh-Oh, you did not get all of the questions right. I will have to kill you now..."')
            time.sleep(0.5)
            print('You die...G A M E   O V E R')
            return False
        return 

    def upstairs(self):
        """

            This function represents the staircase of the house. Here the user has an option of picking up a weapon.

        """
        yes = ['yes', 'y']
        pickup = ['pickup', 'Pickup', 'yes']
        engage = ['engage', 'Engage', 'yes']
        no = ['no', 'No']
        go = ['go', 'Go']
        knife = 0  # Here there is an item the user can pick up, and we initialize the item here
        print('Press "yes" to leave this room and go upstairs. [Enter "yes"]')
        choice = input(">>> ")
        if choice in yes:
            print('You are walking upstairs, when you see a knife on the floor. '
                  'Do you want to pick it up? [Enter "pickup"]')
            choice = input(">>> ")
            if choice in pickup:
                knife += 1
                print('You have picked up the knife and you walk towards the room')
                time.sleep(1)
            else:
                print('You do not pick the knife and walk towards the room')
                time.sleep(1)
        else:
            self.textUI.print_to_textUI("Don't know what you mean.")
            GameRooms.upstairs(self)

        print(
            'You see a monster standing in front of you, You need to engage with it in order to progress. '
            'What would you like to engage?[Enter "engage"]')
        time.sleep(0.5)
        choice = input(">>> ")
        if choice in engage:
            print('You move closer to the monster. The monster spots you and run towards you. '
                  'You check your pockets for a weapon')
            time.sleep(0.5)
            if knife == 1:
                print(' You use the knife you picked up earlier to kill the monster!. You search the room for '
                      'your football. \n You find a box in the room instead.')
                time.sleep(0.5)
                print('do you want to open it? [Enter "yes"]')
                time.sleep(0.5)
                choice = input(">>>")
                if choice in yes:
                    print('You open the box using the knife. You find a note saying that your football is on the roof '
                          'top. Do you wish to go to the roof top?')
                    time.sleep(0.5)
                    print('Press "go" to go')
                    time.sleep(0.5)
                    choice = input(">>>")
                    if choice in go:
                        GameRooms.stairhallway(self)
                    else:
                        return False
                elif choice in no:
                    print('Oh no, You need to open the box to proceed. Restart from last checkpoint')
                    GameRooms.upstairs(self)  # Calling a checkpoint
                return True
            else:
                print('You did not have a weapon to defend yourself...You died. GAME OVER.')
                return False
        elif choice in no:
            print('You chose to not engage but unfortunately for you the monster engages and kills you.'
                  '\nG A M E   O V E R')

        else:
            print('Did not understand. Try again from last checkpoint')
            GameRooms.upstairs(self)  # Calling a checkpoint

    def stairhallway(self):
        """

            This function represents the staircase hallway of the house which leads to the rooftop.
            Here the user can pick an item or drop an item and pick up two items.

        """
        knife = 1
        rocka = 0
        bottlea = 0
        one = ['one']
        two = ['two']
        bottle = ['bottle']
        rock = ['rock']
        rooftop = ['rooftop']
        print('You walk towards the rooftop and on the hallway you see two items: '
              'A rock and a bottle with some water in it.')
        time.sleep(0.5)
        print('Since you already have a knife, your pocket can only hold one more item.')
        time.sleep(0.5)
        print('You can throw away your knife and pick up these two items [Enter "two"] or '
              'choose one of the two items [Enter "one"]')
        choice = input(">>> ")
        if choice in two:
            print('You throw away the knife and pick up the rock and the bottle')
            knife -= 1
            GameRooms.pocket.remove('knife')
            rocka += 1
            bottlea += 1
            if rocka == 1 and bottlea == 1:
                GameRooms.pocket.append('rock')
                GameRooms.pocket.append('bottle')

        elif choice in one:
            print('Enter which item would you like to take? Rock or bottle? [Enter "rock" or Enter "bottle"]')
            choice = input(">>> ")
            if choice in rock:
                rocka += 1
                GameRooms.pocket.append('rock')
            elif choice in bottle:
                bottlea += 1
                GameRooms.pocket.append('bottle')
        print('You have picked up the item. Now your pocket has', GameRooms.pocket)
        time.sleep(0.5)
        print('Press rooftop to enter the rooftop [Enter "rooftop"]')
        choice = input(">>> ")
        if choice in rooftop:
            print('You walk towards the rooftop')
            GameRooms.rooftop(self)
        else:
            print('You decided to not proceed with the game. Press quit to leave the game.')

    def rooftop(self):
        """

            This function represents the rooftop. Here the user completes the task and exits the area into the hallway.

        """
        exit = ['exit', 'Exit']
        print('You are now inside the rooftop')
        time.sleep(0.5)
        print('You finally see your football there!!')
        time.sleep(0.5)
        print('You pick it up. Press "exit" to exit the rooftop [Enter "exit"]')
        time.sleep(0.5)
        choice = input(">>> ")
        if choice in exit:
            print('You leave the rooftop and is back in the hallway')
            time.sleep(0.5)
            print('Press "exit" again to go back downstairs. [Enter "exit"]')
            choice = input(">>> ")
            if choice in exit:
                print('You head back downstairs.')
                time.sleep(0.5)
                print('You go to the door, However you are locked in and there is no key. '
                      'You look back and see 3 other rooms')
                time.sleep(0.5)
                GameRooms.hallway(self)
            else:
                print('Invalid entry')
        else:
            print('You decided to not proceed with the game. Press quit to leave the game.')

    def hallway(self):
        """

            Here, in this function, the user has an option of entering 3 rooms.

        """
        kitchen = ['kitchen']
        bedroom = ['bedroom']
        livingroom = ['livingroom']
        print('The rooms are: kitchen, living room and the bedroom with the figure. Where would you like to go? ')
        print('[Enter "kitchen" or "livingroom or "bedroom"]')
        choice = input(">>> ")
        if choice in kitchen:
            GameRooms.kitchen(self)
        elif choice in livingroom:
            GameRooms.livingroom(self)
        elif choice in bedroom:
            GameRooms.bedroom2(self)
        else:
            print('Invalid entry')

    def kitchen(self):
        """

            This function represents the kitchen of the house and the user has the option of leaving the room and
            going back to the hallway.

        """

        print('You are now in the kitchen. You search for the key. The key is not in the kitchen so you go back.')
        time.sleep(0.5)
        GameRooms.hallway(self)

    def livingroom(self):
        """

            This function represents the livingroom and the user has to find the key and perform a task before
            leaving the room and going back to the hallway.

        """
        checkpoint = ['checkpoint', 'cp']
        print('You are in the living room. On the table, you find the key. But the key is dirty. '
              '\nYou need to wash and clean it inorder to use it.')
        time.sleep(1)
        if 'bottle' in GameRooms.pocket:
            print('You use the water in the bottle you picked up earlier to wash and clean the key.')
            GameRooms.outdoor(self)
        else:
            print('But wait...OOps!, You do not have a water bottle since you did not pick it up at the hallway.')
            time.sleep(0.5)
            print('[Enter "checkpoint" or "cp" to restart from checkpoint]')
            choice = input(">>> ")
            if choice in checkpoint:
                print('You will now return to a checkpoint')
                GameRooms.stairhallway(self)  # calling a checkpoint
            else:
                print('You do not have a working key. You are locked in FOREVER! \nG A M E  O V E R !!!')

    def bedroom2(self):
        """

            This function represents the bedroom of the house and the user has the option of leaving the room and
            going back to the hallway.

        """
        print('You are now in the bedroom. You say "hi" to the strange figure you met earlier. '
              'You then search for the key. The key is not in the bedroom so you go back.')
        GameRooms.hallway(self)

    def outdoor(self):
        """

            This function comes into effect so that the user can leave the house and complete the game.

        """
        print('Using the key, you unlock the door and leave the abandoned house!! ')
        time.sleep(0.5)
        print('Hopefully your friends will believe the adventure you have had :)')
        time.sleep(1)
        print('CONGRATULATIONS, YOU COMPLETED THE GAME.')
        return False
