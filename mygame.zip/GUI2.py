import tkinter as tk
from G2 import Game
from TextUI import TextUI
from Gamerooms import GameRooms
from Navigate import Room
from TextUI import TextUI

class App():

    # Creates a Frame for the application and populates the GUI...
    def __init__(self, root):

        self.GameRooms = GameRooms("")
        self.game = Game()
        self.firstcall()
        self.current_room = self.room1
        #self.game.play()


        #self.firstcall()


        #self.room1.set_exit("inside", self.house)
        #self.house.set_exit("inside", self.room1)


        #self.room1 = True

        # Create two frames owned by the window root.
        # In order to use multiple layout managers, the frames
        # cannot share a parent frame. Here both frames are owned
        # by a top level instance root.

        self.frame1 = tk.Frame(root, width=600, height=150, bg='WHITE', borderwidth=2)
        self.frame1.pack_propagate(0)  # Prevents resizing
        self.frame2 = tk.Frame(root, width=600, height=150, bg='LIGHT GREY', borderwidth=2)
        self.frame2.grid_propagate(0)  # Prevents resizing
        self.frame3 = tk.Frame(root, width=600, height=150, bg='WHITE', borderwidth=2)
        self.frame3.pack_propagate(0)  # Prevents resizing
        # This packs both frames into the root window...
        self.frame4 = tk.Frame(root, width=600, height=150, bg='WHITE', borderwidth=2)
        self.frame4.pack_propagate(0)  # Prevents resizing
        self.frame5 = tk.Frame(root, width=600, height=150, bg='WHITE', borderwidth=2)
        self.frame5.pack_propagate(0)  # Prevents resizing
        self.frame1.pack()
        self.frame2.pack()
        self.frame3.pack()
        self.frame4.pack()
        self.frame5.pack()

        # Now add some useful widgets...
        self.text_area1 = tk.Label(self.frame1, text='')
        self.text_area1.pack()
        self.cmd_area = tk.Entry(self.frame2, text='')
        self.cmd_area.pack()
        self.build_GUI()

        #self.game = Game()

    def firstcall(self):
        """
        Calls the first room of the game.
        """
        GameRooms.bedroom(self)
        #GameRooms.basement(self)



    def build_GUI(self):
        self.cmd_button = tk.Button(self.frame2, text='Run command',
                                    fg='black', bg='blue',
                                    command=self.do_command)
        self.cmd_button.pack()
        self.text_area1.configure(text=self.game.print_welcome())

    def do_command(self):
        command = self.cmd_area.get()  # Returns a 2-tuple
        self.process_command(command)

    def get_command_string(self, input_line):
        """
            Fetches a command (borrowed from old TextUI).
        :return: a 2-tuple of the form (command_word, second_word)
        """
        word1 = None
        word2 = None
        if input_line != "":
            all_words = input_line.split()
            word1 = all_words[0]
            if len(all_words) > 1:
                word2 = all_words[1]
            else:
                word2 = None
            # Just ignore any other words
        return (word1, word2)



    def process_command(self, command):
        """
            Process a command.
        :param command: a 2-tuple of the form (command_word, second_word)
        """
        command_word, second_word = self.get_command_string(command)
        if command_word != None:
            command_word = command_word.upper()
            if command_word == "HELP":
                self.text_area1.configure(text=self.game.print_help())
            elif command_word == "GO":
                self.text_area1.configure(text=self.game.do_go_command(second_word))
            #elif command_word == "ok":
                #self.current_room = GameRooms.basement
                #return f'{GameRooms.basement(self)}'

            else:
                # Unknown command...
                #self.text_area1.configure(text=self.GameRooms.basement())
                return f'{GameRooms.basement(self)}'



    

def main():
    win = tk.Tk()                           # Create a window
    win.title("Adventure World with GUI")   # Set window title
    win.geometry("600x500")                 # Set window size
    win.resizable(False, False)             # Both x and y dimensions...

    # Create the GUI as a Frame and attach it to the window...

    App(win)




    # Call the GUI mainloop...
    win.mainloop()
    win.mainloop()

if __name__ == "__main__":
    main()
