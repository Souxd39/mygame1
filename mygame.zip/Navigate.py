"""

This class handles the navigation of the user while the programme is running.

"""
class Room:

    def __init__(self, description):
        """
            Constructor method.
        :param description: Text description for this room
        """
        self.description = description
        self.exits = {}  # Dictionary

    def set_exit(self, direction, neighbour):
        """
            Adds an exit for a room. The exit is stored as a dictionary
            entry of the (key, value) pair (direction, room).

        """
        self.exits[direction] = neighbour

    def get_short_description(self):
        """
            Fetch a short text description.

        """
        return self.description

    def get_long_description(self):
        """
            Fetch a longer description including available exits.

        """
        return f' {self.description}'

    def get_exits(self):
        """
            Fetch all available exits as a list.

        """
        all_exits = list(self.exits.keys())
        return all_exits


    def get_exit(self, direction):
        """
            Fetch an exit in a specified direction.

        """
        if direction in self.exits:
            return self.exits[direction]
        else:
            return None
