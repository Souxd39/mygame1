"""
***Find the football***
Below is the main class of the game. It is using this file and class that we can run and initialize the game.

"""
from Navigate import Room
from TextUI import TextUI
from Gamerooms import GameRooms
import time


class Game:

    def __init__(self):

        self.firstcall()
        self.current_room = self.room1
        self.textUI = TextUI()

    def firstcall(self):
        """
        Calls the first room of the game.
        """
        return f'{GameRooms.bedroom(self)}' # Will call the bedroom function from the Game_Rooms class

    def play(self):  # This function will run the game by first displaying the welcome message.
        """

        will call the welcome function and loop through the rooms

        """

        self.print_welcome()
        finished = False
        while not finished:
            command = self.textUI.get_command()
            finished = self.process_command(command)
        return

    def print_welcome(self):  # Will print the welcome display message of the game.
        """

        The games welcome messages will be displayed by this function

        """
        self.msg = \
            f'You and your friends were playing football when you kicked the ball out by accident \n \
                ball flew into an old creepy abandoned house and now your mates are asking you to bring the ball back \n \
                You being an adventurous person is up for the challenge and decide to bring back the ball \n \
                You are now standing in front of the house \n \
                What would you do now!? \n \
                Your command words are: {self.show_command_words()}'

        return self.msg

    def show_command_words(self):  # Will display the command words the user uses in the game.
        """

        Will display the text as an argument for show_command_words in print_welcome()

        """
        return ['"help" to get help', ' "go" to start the game', '"quit" to quit the game']

    def process_command(self, command):  # Will process the command words the user enters
        """

        Checks the user input and the command word

        """
        command_word, second_word = command
        if command_word != None:
            command_word = command_word.upper()

        want_to_quit = False
        if command_word == "HELP":
            self.print_help()
        elif command_word == "GO":
            self.do_go_command(second_word)
        #elif command_word == 'ok':

            #return f'{GameRooms.basement(self)}'
        elif command_word == "QUIT":
            print("You run away scared. GAME OVER")
            want_to_quit = True
        else:
            # Unknown command...
            self.textUI.print_to_textUI("Don't know what you mean.")

        return want_to_quit

    def print_help(self):  # Will print the help display message of the game.
        """

        Prints the help text for when help is required

        """

        self.textUI.print_to_textUI(
            "You and your friends were playing football when you kicked the ball out by accident.")
        time.sleep(0.5)
        self.textUI.print_to_textUI(
            "The ball flew into an old creepy abandoned house and now your mates are asking you to bring the ball back")
        time.sleep(0.5)
        self.textUI.print_to_textUI(
            "You being an adventurous person is up for the challenge and decide to bring back the ball")
        time.sleep(0.5)
        self.textUI.print_to_textUI("You are now standing in front of the house")
        time.sleep(0.5)
        self.textUI.print_to_textUI("What would you do now!?")
        time.sleep(0.5)
        self.textUI.print_to_textUI(f'Your command words are: {self.show_command_words()}')
        time.sleep(0.5)

    def do_go_command(self, second_word):  # Helps the user initialize the second word from the input
        """
        Pass the second word as an argument.

        """

        if second_word == None:
            # Missing second word...
            self.msg = \
                f'Would you like to go inside the house? [ Enter go inside to proceed]'
            #self.textUI.print_to_textUI("Would you like to go inside the house? [ Enter 'go inside' to proceed]")
            return self.msg

        next_room = self.current_room.get_exit(second_word)
        if next_room == None:
            return f'{self.textUI.print_to_textUI("There is no room!")}'
        else:
            self.current_room = next_room
            return f'{self.current_room.get_long_description()}'

        return
